# Ponto da Hora
#### Extensão do Chrome para facilitar a visualização do banco de horas

1. Saldo do banco de horas  (As horas de Sábado são computadas diariamente entre os dias trabalhados de Segunda à Sexta )

2. Previsão de saída.

3. Horário limite para saída (Considerando o limite de 10 horas trabalhadas no dia)
